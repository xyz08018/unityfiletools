package com.kyd.unitycustom;

import android.Manifest;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.AudioManager;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.FileProvider;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;

import com.kyd.unitycustom.wxapi.WXPayEntryActivity;
import com.kyd.unitycustom.PayDemoActivity;
import com.tencent.mm.opensdk.modelbiz.WXLaunchMiniProgram;
import com.tencent.mm.opensdk.modelmsg.SendMessageToWX;
import com.tencent.mm.opensdk.modelmsg.WXImageObject;
import com.tencent.mm.opensdk.modelmsg.WXMediaMessage;
import com.tencent.mm.opensdk.modelmsg.WXWebpageObject;
import com.tencent.mm.opensdk.modelpay.PayReq;
import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.WXAPIFactory;
import com.unity3d.player.UnityPlayer;
import com.unity3d.player.UnityPlayerActivity;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

import android.content.ComponentName;

public class MainActivity extends UnityPlayerActivity {

    private static final String TAG = "MainActivity";
    private String path;
    Context mContext = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = this;
    }

    public String Add(int a, int b) {
        String s = "unityArr Add() = > " + (a + b);
        UnityPlayer.UnitySendMessage("Global", "DebugByUnity", s);
        return s;
    }



    public void InvokeTest(String a) {
        UnityPlayer.UnitySendMessage("Global", "DebugByUnity", a);
    }


    //打开相册
    public void TakePhoto(String type) {
        Log.d("Unity", "falg = " + "TakePhoto");//
        Intent intent = new Intent(Intent.ACTION_PICK, null);
        intent.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*");
        startActivityForResult(intent, 2);
    }

    /**
     * 检测并安装Apk
     */
    public void checkIsAndroidO(String path) {
        this.path = path;
        Log.d(TAG, "checkIsAndroidO: " + path);
        if (Build.VERSION.SDK_INT >= 26) {
            boolean b = getPackageManager().canRequestPackageInstalls();
            if (b) {
                installAPK();
            } else {
                //设置安装未知应用来源的权限
                Intent intent = new Intent();
                //获取当前apk包URI，并设置到intent中（这一步设置，可让“未知应用权限设置界面”只显示当前应用的设置项）
                Uri packageURI = Uri.parse("package:" + getPackageName());
                intent.setData(packageURI);
                //设置不同版本跳转未知应用的动作
                if (Build.VERSION.SDK_INT >= 26) {
                    //intent = new Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,packageURI);
                    intent.setAction(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES);
                } else {
                    intent.setAction(android.provider.Settings.ACTION_SECURITY_SETTINGS);
                }
                startActivityForResult(intent, 10012);
            }
        } else {
            installAPK();
        }
    }

    private void installAPK() {
        if (path == null || path.isEmpty()) {
            return;
        }
        Log.d(TAG, "installAPK: 安装apk");
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_VIEW);
        intent.addCategory("android.intent.category.DEFAULT");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        Uri uri;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            uri = FileProvider.getUriForFile(this, "com.kyd.unitycustom.fileProvider", new File(path));
        } else {
            uri = Uri.fromFile(new File(path));
        }
        intent.setDataAndType(uri, "application/vnd.android.package-archive");
        startActivity(intent);
        path = null;
        finish();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 2) {
            if (data != null) {
                Uri uri = data.getData();
                String path = getRealFilePath(this, uri);
                Log.i("unity", "照片：path = " + path);
                UnityPlayer.UnitySendMessage("FeedBackTalk_CallbackAndroid", "ClkSendPhoto", path);
            }
        } else if (requestCode == 10012) {
            checkIsAndroidO(path);
        }
    }

    public static String getRealFilePath(final Context context, final Uri uri) {
        if (null == uri) return null;
        final String scheme = uri.getScheme();
        String data = null;
        if (scheme == null) {
            data = uri.getPath();
        } else if (ContentResolver.SCHEME_FILE.equals(scheme)) {
            data = uri.getPath();
        } else if (ContentResolver.SCHEME_CONTENT.equals(scheme)) {
            Cursor cursor = context.getContentResolver().query(uri, new String[]{MediaStore.Images.ImageColumns.DATA}, null, null, null);
            if (null != cursor) {
                if (cursor.moveToFirst()) {
                    int index = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
                    if (index > -1) {
                        data = cursor.getString(index);
                    }
                }
                cursor.close();
            }
        }
        return data;
    }

    public String GetID() {

        String serial = null;

        String m_szDevIDShort = "35" +
                Build.BOARD.length() % 10 + Build.BRAND.length() % 10 +

                Build.CPU_ABI.length() % 10 + Build.DEVICE.length() % 10 +

                Build.DISPLAY.length() % 10 + Build.HOST.length() % 10 +

                Build.ID.length() % 10 + Build.MANUFACTURER.length() % 10 +

                Build.MODEL.length() % 10 + Build.PRODUCT.length() % 10 +

                Build.TAGS.length() % 10 + Build.TYPE.length() % 10 +

                Build.USER.length() % 10; //13 位
        try {
            serial = android.os.Build.class.getField("SERIAL").get(null).toString();
            //API>=9 使用serial号
            return new UUID(m_szDevIDShort.hashCode(), serial.hashCode()).toString();
        } catch (Exception exception) {
            //serial需要一个初始化
            serial = "serial"; // 随便一个初始化
        }
        return new UUID(m_szDevIDShort.hashCode(), serial.hashCode()).toString();
        //使用硬件信息拼凑出来的15位号码
    }


    //微信支付
    private IWXAPI msgApi;

    public void weichatPay(String appId, String partnerId, String prepayId, String nonceStr, String timeStamp, String sign) {
        WXPayEntryActivity.APP_ID = appId;
        msgApi = WXAPIFactory.createWXAPI(this, appId);
        PayReq request = new PayReq();
        request.appId = appId;
        request.partnerId = partnerId;
        request.prepayId = prepayId;
        request.packageValue = "Sign=WXPay";
        request.nonceStr = nonceStr;
        request.timeStamp = timeStamp;
        request.sign = sign;
        Log.d("Unity", request.checkArgs() + "!!");//输出验签是否正确
        boolean flag = msgApi.sendReq(request);
        Log.d("Unity", "falg = " + flag);//输出验签是否正确
    }

    //打电话注销帐号
    public void CancelAccountTakePhone(String phoneNum) {
        Intent intent = new Intent(Intent.ACTION_CALL);
        Uri data = Uri.parse("tel:" + phoneNum);
        intent.setData(data);
        startActivity(intent);
    }


    public boolean CheckWeChat() {
        Log.d("Unity", "falg = " + "wechatInstallCheck");//
        IWXAPI wxApi = WXAPIFactory.createWXAPI(mContext, WXPayEntryActivity.APP_ID);

        boolean bIsWXAppInstalledAndSupported = wxApi.isWXAppInstalled();
        if (!bIsWXAppInstalledAndSupported) {
            final PackageManager packageManager = mContext.getPackageManager();// 获取packagemanager
            List<PackageInfo> pinfo = packageManager.getInstalledPackages(0);// 获取所有已安装程序的包信息
            if (pinfo != null) {
                for (int i = 0; i < pinfo.size(); i++) {
                    String pn = pinfo.get(i).packageName;
                    if (pn.equals("com.tencent.mm")) {
                        return true;
                    }
                }
            }
            return false;
        }
        return true;
    }

    public void  CheckAndroidDeviceData()
    {

        boolean resultali = CheckApiPay();
        boolean resultwechat = CheckWeChat();
        //String mac=getLocalMacAddressFromIp();
        String mac=getNewMac(mContext);
        String imei=getIMEI(mContext);
        String ip=getLocalMacAddressIp();
        String ug=getUg();
        String model=getMODEL();
        if(imei==null)
        {
            imei="null";
        }
        Log.d("unity_test", "CheckAndroidDeviceData mac: " + mac +"imei； " + imei+"ip:   "+ip+"ug：   "+ug);
        PayDemoActivity.callUnity("Global", "ApiPayInstallCheckCallBack", String.valueOf(resultali));
        PayDemoActivity.callUnity("Global", "WeChatInstallCheckCallBack", String.valueOf(resultwechat));
        PayDemoActivity.callUnity("Global", "GetAndroidIMEICallBack", imei);
        PayDemoActivity.callUnity("Global", "GetAndroidMACCallBack", mac);
        PayDemoActivity.callUnity("Global", "GetAndroidMIPCallBack", ip);
        PayDemoActivity.callUnity("Global", "GetAndroidMUGCallBack", ug);
        PayDemoActivity.callUnity("Global", "GetAndroidModalCallBack", model);

    }

    public  void  GetDeviceVolume()
    {
        AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        int max = audioManager.getStreamMaxVolume( AudioManager.STREAM_MUSIC );
        //int current = audioManager.getStreamVolume( AudioManager.STREAM_SYSTEM );
        int current=audioManager.getStreamVolume( AudioManager.STREAM_MUSIC );
        Log.d("unity_test", "volume max: " +String.valueOf(max) +"current； " + String.valueOf(current));
        PayDemoActivity.callUnity("Global", "GetCurDeviceVolume", String.valueOf(current));
        PayDemoActivity.callUnity("Global", "GetMaxDeviceVolume", String.valueOf(max));
    }
/////////////////不用过ip获取mac////////////////////////////
//https://www.jianshu.com/p/de7cbcb4fd3e
    //安卓10以下不用拿
    public static String getNewMac(Context context) {
        String mac = "";
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return mac;
            //mac = getMacDefault(context);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            //mac = getNewMacAddress();
            return mac;
            //原文N被我修改为M
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            mac = getNewMacFromHardware();
        }
        return mac;
    }

    /**
     * Android 6.0 之前（不包括6.0）获取mac地址
     * 必须的权限 <uses-permission android:name="android.permission.ACCESS_WIFI_STATE"></uses-permission>
     * @param context * @return
     */
    public static String getMacDefault(Context context) {
        String mac = "";
        if (context == null) {
            return mac;
        }
        WifiManager wifi = (WifiManager)context.getSystemService(Context.WIFI_SERVICE);
        WifiInfo info = null;
        try {
            info = wifi.getConnectionInfo();
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (info == null) {
            return null;
        }
        mac = info.getMacAddress();
        if (!TextUtils.isEmpty(mac)) {
            mac = mac.toUpperCase(Locale.ENGLISH);
        }
        return mac;
    }

    /**
     * Android 6.0-Android 7.0 获取mac地址
     */
    public static String getNewMacAddress() {
        String macSerial = null;
        String str = "";

        try {
            Process pp = Runtime.getRuntime().exec("cat/sys/class/net/wlan0/address");
            InputStreamReader ir = new InputStreamReader(pp.getInputStream());
            LineNumberReader input = new LineNumberReader(ir);

            while (null != str) {
                str = input.readLine();
                if (str != null) {
                    macSerial = str.trim();//去空格
                    break;
                }
            }
        } catch (IOException ex) {
            // 赋予默认值
            ex.printStackTrace();
        }

        return macSerial;
    }

    /**
     * Android 7.0之后获取Mac地址
     * 遍历循环所有的网络接口，找到接口是 wlan0
     * 必须的权限 <uses-permission android:name="android.permission.INTERNET"></uses-permission>
     * @return
     */
    public static String getNewMacFromHardware() {
        try {
            ArrayList<NetworkInterface> all = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface nif:all) {
                if (!nif.getName().equals("wlan0"))
                    continue;
                byte[] macBytes = nif.getHardwareAddress();
                if (macBytes == null) return "";
                StringBuilder res1 = new StringBuilder();
                for (Byte b : macBytes) {
                    res1.append(String.format("%02X:", b));
                }
                if (!TextUtils.isEmpty(res1)) {
                    res1.deleteCharAt(res1.length() - 1);
                }
                return res1.toString();
            }
        }
        catch (SocketException e)
        {
            e.printStackTrace();
        }
        return "";
    }

    //////////////////////////////////////////////////////////////////////

    public boolean CheckApiPay() {
        Log.d("Unity", "falg = " + "alipayInstallCheck");//
        Uri uri = Uri.parse("alipays://platformapi/startApp");
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        ComponentName componentName = intent.resolveActivity(mContext.getPackageManager());
        return componentName != null;
    }

    //打开微信小程序接口
    public void OpenWeChatSmallProgram() {
        String appId = "wxda445c2b2b452f25"; // 填对应开发平台移动应用AppId
        IWXAPI api = WXAPIFactory.createWXAPI(mContext, appId);

        String smallProgramPath = "pages/index/index";    //小程序页面URL
        WXLaunchMiniProgram.Req req = new WXLaunchMiniProgram.Req();
        req.userName = "gh_030703d45b4f"; // 填小程序原始id(奇米小课堂)
        req.path = smallProgramPath; //req.path="page/index?key1=xxx&key2=yyy";                 ////拉起小程序页面的可带参路径，不填默认拉起小程序首页，对于小游戏，可以只传入 query 部分，来实现传参效果，如：传入 "?foo=bar"。
        req.miniprogramType = WXLaunchMiniProgram.Req.MINIPTOGRAM_TYPE_RELEASE;// 可选打开 开发版，体验版和正式版
        api.sendReq(req);
        Log.d("Unity", "miniprogram, appId = " + appId);

        //PayDemoActivity.callUnity("CourseSystemSelectCtl", "OpenWeChatSmallProgramCallback", String.valueOf(ret));
    }

    //微信分享URL
    public void WeChatShareUrl(String url,String iconPath,String title,String descrip,String type) throws FileNotFoundException
    {
        IWXAPI api = WXAPIFactory.createWXAPI(mContext, "wxda445c2b2b452f25");
        WXWebpageObject webpage=new WXWebpageObject();
        webpage.webpageUrl=url;
        FileInputStream fis = new FileInputStream(iconPath);  //icon 放服务器上
        Bitmap bp = BitmapFactory.decodeStream(fis);
        WXMediaMessage msg=new WXMediaMessage(webpage);
        msg.title=title;
        msg.description=descrip;
        //设置缩略图
        //Bitmap bitmap = BitmapFactory.decodeResource(getResources(),R.drawable.share);  //icon放本地模式
        //Bitmap thumbBmp = Bitmap.createScaledBitmap(bitmap,120,120, true);
        msg.thumbData= bmpToByteArray(bp, true);
        //构造一个Req
        SendMessageToWX.Req req = new SendMessageToWX.Req();
        req.transaction = buildTransaction("webpage");
        req.message =msg;
        if(type.equals("0"))
        {
            Log.d("Unity","0000");
            req.scene = SendMessageToWX.Req.WXSceneSession;
        }
        else
        {
            Log.d("Unity","11111");
            req.scene = SendMessageToWX.Req.WXSceneTimeline;
        }
        api.sendReq(req);
    }

    //微信图片分享
    public void WeChatShareToAn(String imgPath,String type) throws FileNotFoundException {
        IWXAPI api = WXAPIFactory.createWXAPI(mContext, "wxda445c2b2b452f25");
        //Bitmap bp = IMServer.getDiskBitmap(IMServer.url);   //本地路径读取图片
        Log.d("Unity", "WeChatShareToAndriod, path = " + imgPath+" type= "+type);
        FileInputStream fis = new FileInputStream(imgPath);
        Bitmap bp = BitmapFactory.decodeStream(fis);
        WXImageObject wxImageObject = new WXImageObject(bp);
        WXMediaMessage msg = new WXMediaMessage();
        msg.mediaObject = wxImageObject;
        //设置缩略图
        Bitmap mBp = Bitmap.createScaledBitmap(bp, 120, 120, true);
        bp.recycle();
        msg.thumbData = bmpToByteArray(mBp, true);
        SendMessageToWX.Req req = new SendMessageToWX.Req();
        req.transaction = buildTransaction("img");//  transaction字段用
        req.message = msg;
        if(type.equals("0"))
        {
            Log.d("Unity","0000");
            req.scene = SendMessageToWX.Req.WXSceneSession;
        }
        else
        {
            Log.d("Unity","11111");
            req.scene = SendMessageToWX.Req.WXSceneTimeline;
        }
        api.sendReq(req);
    }

    public static byte[] bmpToByteArray(final Bitmap bmp, final boolean needRecycle) {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.PNG, 100, output);
        if (needRecycle) {
            bmp.recycle();
        }

        byte[] result = output.toByteArray();
        try {
            output.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    private String buildTransaction(final String type) {
        return (type == null) ? String.valueOf(System.currentTimeMillis()) : type + System.currentTimeMillis();
    }



    public static String getIMEI(Context context) {
        Log.d("Unity", "falg = " + "getIMEI");
        TelephonyManager manager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        try {
            Method method = manager.getClass().getMethod("getImei", int.class);
            String imei1 = (String) method.invoke(manager, 0);
            String imei2 = (String) method.invoke(manager, 1);
            if(TextUtils.isEmpty(imei2)){
                return imei1;
            }
            if(!TextUtils.isEmpty(imei1)){
                //因为手机卡插在不同位置，获取到的imei1和imei2值会交换，所以取它们的最小值,保证拿到的imei都是同一个
                String imei = "";
                if(imei1.compareTo(imei2) <= 0){
                    imei = imei1;
                }else{
                    imei = imei2;
                }
                return imei;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
        return "";
    }


    public static String getUg()
    {
        String userAgent = System.getProperty("http.agent");
        return  userAgent;
    }

    public static String getMODEL()
    {
        return android.os.Build.MODEL;
    }

    /**
     * 根据IP地址获取MAC地址
     *
     * @return
     */
    private static String getLocalMacAddressFromIp() {
        Log.d("Unity", "falg = " + "getLocalMacAddressFromIp");
        String strMacAddr = null;
        try {
            //获得IpD地址
            InetAddress ip = getLocalInetAddress();
            byte[] b = NetworkInterface.getByInetAddress(ip).getHardwareAddress();
            StringBuffer buffer = new StringBuffer();
            for (int i = 0; i < b.length; i++) {
                if (i != 0) {
                    buffer.append(':');
                }
                String str = Integer.toHexString(b[i] & 0xFF);
                buffer.append(str.length() == 1 ? 0 + str : str);
            }
            strMacAddr = buffer.toString().toUpperCase();
        } catch (Exception e) {

        }

        return strMacAddr;
    }

    /**
     * 根据IP地址
     *
     * @return
     */
    private static String getLocalMacAddressIp() {
        Log.d("Unity", "falg = " + "getLocalMacAddressFromIp");
        String strip = null;
        try {
            //获得IpD地址
            InetAddress ip = getLocalInetAddress();
            strip=ip.getHostAddress();
            return strip;
        } catch (Exception e) {

        }

        return strip;
    }

    /**
     * 获取移动设备本地IP
     *
     * @return
     */
    private static InetAddress getLocalInetAddress() {
        InetAddress ip = null;
        try {
            //列举
            Enumeration<NetworkInterface> en_netInterface = NetworkInterface.getNetworkInterfaces();
            while (en_netInterface.hasMoreElements()) {//是否还有元素
                NetworkInterface ni = (NetworkInterface) en_netInterface.nextElement();//得到下一个元素
                Enumeration<InetAddress> en_ip = ni.getInetAddresses();//得到一个ip地址的列举
                while (en_ip.hasMoreElements()) {
                    ip = en_ip.nextElement();
                    if (!ip.isLoopbackAddress() && ip.getHostAddress().indexOf(":") == -1)
                        break;
                    else
                        ip = null;
                }

                if (ip != null) {
                    break;
                }
            }
        } catch (SocketException e) {

            e.printStackTrace();
        }
        return ip;

    }

    /*
    //保存文件到指定路径
    public void saveImageToGallery(String imgPath,String imgName) {
        // 首先保存图片

        Log.d("Unity", "falg = " + "saveImageToGallery");
        //String storePath = Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + "dearxy";
        File appDir = new File(imgPath);
        if (!appDir.exists()) {
            appDir.mkdir();
        }
        File file = new File(appDir, imgName);
        try {

            //把文件插入到系统图库
             MediaStore.Images.Media.insertImage(mContext.getContentResolver(), file.getAbsolutePath(), imgName, null);

            //保存图片后发送广播通知更新数据库
            Uri uri = Uri.fromFile(file);
            mContext.sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, uri));

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
     */

    public void copyCont(String cont)
    {
        //获取剪贴版
        ClipboardManager clipboard = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
//创建ClipData对象
//第一个参数只是一个标记，随便传入。
//第二个参数是要复制到剪贴版的内容
        ClipData clip = ClipData.newPlainText("simple text", cont);
//传入clipdata对象.
        clipboard.setPrimaryClip(clip);

        PayDemoActivity.callUnity("Global", "CopyText",String.valueOf(1));
    }

    public void  saveQRCode(String path)
    {
        Log.d("Unity", "falg = " + "saveQRCode");
        Boolean isSuccess=saveImageToGallery(path);
        Log.d("Unity", "falg = " +String.valueOf(isSuccess) );
        if(isSuccess) {
            PayDemoActivity.callUnity("Global", "SaveQRCodeSuccess",String.valueOf(isSuccess));
        }
    }


        //保存文件到指定路径
    public boolean saveImageToGallery(String pathName) {
        // 首先保存图片
        Log.d("Unity", "falg = " + "saveImageToGallery");
        Bitmap bitmap = BitmapFactory.decodeFile(pathName);
        String storePath = Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + "dearxy";
        File appDir = new File(storePath);
        if (!appDir.exists()) {
            appDir.mkdir();
        }
        String fileName = System.currentTimeMillis() + ".jpg";
        File file = new File(appDir, fileName);
        try {
            FileOutputStream fos = new FileOutputStream(file);
            //通过io流的方式来压缩保存图片
            boolean isSuccess = bitmap.compress(Bitmap.CompressFormat.JPEG, 60, fos);
            fos.flush();
            fos.close();

            //把文件插入到系统图库
            //MediaStore.Images.Media.insertImage(context.getContentResolver(), file.getAbsolutePath(), fileName, null);

            //保存图片后发送广播通知更新数据库
            Uri uri = Uri.fromFile(file);
            mContext.sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, uri));
            if (isSuccess) {
                return true;
            } else {
                return false;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }


}
