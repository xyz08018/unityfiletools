package com.kyd.unitycustom;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.content.FileProvider;
import android.util.Log;
import android.view.View;

import com.unity3d.player.UnityPlayer;

import java.io.File;

/**
 * @author yuweifan
 * @create 2020/8/22 9:57
 * @class describe
 */
public class TestActivity extends Activity {

    private String path;
    private static final String TAG = "TestActivity";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);
        findViewById(R.id.install).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkIsAndroidO(Environment.getExternalStorageDirectory() + File.separator + "LetMePin.apk");
            }
        });
    }

    /**
     * 检测并安装Apk
     */
    public void checkIsAndroidO(String path) {
        this.path = path;
        Log.d(TAG, "checkIsAndroidO: " + path);
        if (Build.VERSION.SDK_INT >= 26) {
            boolean b = getPackageManager().canRequestPackageInstalls();
            if (b) {
                installAPK();
            } else {
                //设置安装未知应用来源的权限
                Intent intent = new Intent();
                //获取当前apk包URI，并设置到intent中（这一步设置，可让“未知应用权限设置界面”只显示当前应用的设置项）
                Uri packageURI = Uri.parse("package:" + getPackageName());
                intent.setData(packageURI);
                //设置不同版本跳转未知应用的动作
                if (Build.VERSION.SDK_INT >= 26) {
                    //intent = new Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,packageURI);
                    intent.setAction(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES);
                } else {
                    intent.setAction(android.provider.Settings.ACTION_SECURITY_SETTINGS);
                }
                startActivityForResult(intent, 10012);
            }
        } else {
            installAPK();
        }
    }

    private void installAPK() {
        if (path == null || path.isEmpty()) {
            return;
        }
        Log.d(TAG, "installAPK: 安装apk");
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_VIEW);
        intent.addCategory("android.intent.category.DEFAULT");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        Uri uri;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            uri = FileProvider.getUriForFile(this, "com.kyd.unitycustom.fileProvider", new File(path));
        } else {
            uri = Uri.fromFile(new File(path));
        }
        intent.setDataAndType(uri, "application/vnd.android.package-archive");
        startActivity(intent);
        path = null;
        finish();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 2) {
            if (data != null) {
                Uri uri = data.getData();
                String path = getRealFilePath(this, uri);
                Log.i("unity", "照片：path = " + path);
                UnityPlayer.UnitySendMessage("FeedBackTalk_CallbackAndroid", "ClkSendPhoto", path);
            }
        } else if (requestCode == 10012) {
            checkIsAndroidO(path);
        }
    }

    public static String getRealFilePath(final Context context, final Uri uri) {
        if (null == uri) return null;
        final String scheme = uri.getScheme();
        String data = null;
        if (scheme == null) {
            data = uri.getPath();
        } else if (ContentResolver.SCHEME_FILE.equals(scheme)) {
            data = uri.getPath();
        } else if (ContentResolver.SCHEME_CONTENT.equals(scheme)) {
            Cursor cursor = context.getContentResolver().query(uri, new String[]{MediaStore.Images.ImageColumns.DATA}, null, null, null);
            if (null != cursor) {
                if (cursor.moveToFirst()) {
                    int index = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
                    if (index > -1) {
                        data = cursor.getString(index);
                    }
                }
                cursor.close();
            }
        }
        return data;
    }
}
